/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: FMDemoRTLSDR_DLL_data.c
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 19-Apr-2022 23:48:43
 */

/* Include Files */
#include "FMDemoRTLSDR_DLL_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_FMDemoRTLSDR_DLL = false;

/*
 * File trailer for FMDemoRTLSDR_DLL_data.c
 *
 * [EOF]
 */
