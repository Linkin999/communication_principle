/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: FMDemoRTLSDR_DLL_types.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 19-Apr-2022 23:48:43
 */

#ifndef FMDEMORTLSDR_DLL_TYPES_H
#define FMDEMORTLSDR_DLL_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for FMDemoRTLSDR_DLL_types.h
 *
 * [EOF]
 */
